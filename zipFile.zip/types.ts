
export interface Pin {
  id: string;
  url: string;
  prompt: string;
}
